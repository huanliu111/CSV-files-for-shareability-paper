# Parameter-analysis inputs and supporting tables

This directory separates the operational sensitivity analysis in Section 7.5 from the supplementary learning-parameter analysis.

## Operational settings

[operational_dense/parameter_grid.csv](operational_dense/parameter_grid.csv) records the controlled one-factor settings. [run_manifest.csv](operational_dense/run_manifest.csv) records their seeds and execution scope. Controlled settings use 30 matched replications; equipment replay uses the same 37 windows from 19 source weeks documented in [02_equipment_replay](../02_equipment_replay/README.md).

The retained `park_raw.csv`, `trace_raw.csv`, summary tables, `Fig5_source.csv`, `Fig6_source.csv`, and `primary_paired_tests.csv` are **simulation outputs and statistical supporting tables**, rather than empirical input observations. `completion.json` and `source_manifest.csv` preserve the original run metadata and historical working paths.

## Supplementary learning inputs

[learning_supplement/inputs/](learning_supplement/inputs/) contains ten TORQ-derived market sequences with seeds `123110`–`123119`. Each contains 400 rounds, four categories, and 12 MDs and 12 MPs per category. Their fields and source-order links follow the [shared TORQ mapping](../01_sources/TORQ/README.md).

The same ten sequences support changes to window length, exploration coefficients, willingness memory, minimum participation probability, and satisfaction scale. They are distinct from the 30 confirmation sequences used in Section 7.4. This directory retains their inputs; it does not contain the supplementary learning-result tables from the earlier full package.
