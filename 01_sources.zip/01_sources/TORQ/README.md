# TORQ order source and economic mapping

**Source:** the financial opening-order extract released by Segal-Halevi, Hassidim, and Aumann for *MUDA: A Truthful Multi-Unit Double-Auction Mechanism* (AAAI, 2018). [Paper DOI](https://doi.org/10.1609/aaai.v32i1.11450) · [Author repository at the retained source commit](https://github.com/erelsgl/double-auction/tree/8e1ffe69b22bdb8bb37a01723088e77e7dd1a7eb).

## Files

| File | Role |
|---|---|
| [raw/901101-910131-SOD.CSV](raw/901101-910131-SOD.CSV) | Original 210,597 financial orders from 1990–1991. |
| [raw/901101-910131-SOD-PRICES.CSV](raw/901101-910131-SOD-PRICES.CSV) | Original source reference-price table. |
| [orders_clean.csv](orders_clean.csv) | 210,595 retained orders after excluding two nonpositive-quantity rows; includes source identifiers and normalized fields. |
| [excluded_source_rows.csv](excluded_source_rows.csv) | Original line numbers and exclusion reasons. |
| [calibration.csv](calibration.csv) | Quantity scale and the source-coverage criterion. |
| [category_mapping.csv](category_mapping.csv) | Four service categories, their units, price scales, quantity factors, and support bounds. |
| [counterexample_source_pair.csv](counterexample_source_pair.csv) | Source types and baseline quantities for the controlled example outside the bounded-quantity assumption. |

## Conversion and source links

For each order, `PriceRatio = ObservedPrice / ReferencePrice`, where `ReferencePrice` is the source symbol's median retained order price. For category `n`:

```text
TrueType = PriceRatio × PriceScale(n)
VerifiedQuantity = ObservedQuantity × QuantityScale × QuantityFactor(n)
```

The quantity scale is `0.0001729956713001485`: the median S1 scenario release hours divided by 12 times the median source order quantity. Price scales are normalized value units, not observed manufacturing prices. `TrueType` denotes the model valuation/cost proxy.

Each sampled input row retains `SourceOrderID`. This joins to `orders_clean.csv`, whose `SourceLine` locates the original order, including the CSV header as line 1. Virtual participants may reuse source orders; they are not observed factories or tracked original traders.

Retain the original data attribution. [raw/LICENSE.upstream](raw/LICENSE.upstream) is the upstream code license; it does not by itself relicense NYSE/TORQ data. This repository grants no additional rights to those records.
