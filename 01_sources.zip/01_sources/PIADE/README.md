# PIADE equipment-state source

**Source:** Tosato, D., Convento, E., Masiero, C., Susto, G. A., and Beghi, A. (2022). *Packaging Industry Anomaly DEtection (PIADE) Dataset*, version 1.0.0. [Dataset DOI](https://doi.org/10.5281/zenodo.7071747).

[`raw_data.csv.gz`](raw_data.csv.gz) is a lossless compression of the original CSV: 429,394 interval records from five packaging machines (`s_1`–`s_5`). Decompression restores the original file without changing its values or row order.

The replay uses `equipment_ID`, `type`, `start`, and `end` to identify equipment, operating states, and interval boundaries. Other source columns remain unchanged. The derived tables in [02_equipment_replay](../../02_equipment_replay/README.md) aggregate these intervals into half-hour slots and retain references to their source rows.

The decompressed source SHA-256 is:

```text
b52561a399d714aa3b084520d6bf86d66c1d2f010fc8cbe1d85b2332806fcb72
```

The [University of Padova metadata](https://researchdata.cab.unipd.it/1459/) identifies the source CSV as CC BY 4.0. See [DATA_LICENSE.md](DATA_LICENSE.md) for attribution. The source contains equipment states; external sharing requests, costs, and release permissions are introduced separately as scenario inputs.
