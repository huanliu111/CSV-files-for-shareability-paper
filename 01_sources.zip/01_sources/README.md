# Original sources and input conversion

Two public sources provide the observed records used to construct the experimental inputs:

- [PIADE](PIADE/README.md): industrial packaging-equipment intervals used to derive the equipment-state replay inputs.
- [TORQ](TORQ/README.md): the MUDA authors' financial order extract, used to construct auction and repeated bidding inputs through explicit price and quantity conversions.

PIADE supplies equipment observations; TORQ supplies empirical order distributions. Manufacturing service labels, external requests, release permissions, and economic unit conversions are declared scenario assumptions. The source READMEs identify the original references, retained files, conversion rules, and attribution requirements.
