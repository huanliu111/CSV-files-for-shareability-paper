# Repeated bidding inputs

These inputs support the original price-factor SW-UCB experiments in Section 7.4. The [inputs/](inputs/) directory contains 30 fixed market sequences, with seeds `123140`–`123169`. Each sequence has 400 rounds, four separately cleared categories, and 12 potential MDs and 12 potential MPs per category: 38,400 rows per CSV.

The [market registry](market_registry.csv) records each sequence's seed, selected source symbols, participant counts, and path. Inputs follow the shared [TORQ conversion](../01_sources/TORQ/README.md). Within each category, source dates advance in nondecreasing order; orders are sampled with replacement from the appropriate side on the selected date.

Each row identifies `(Seed, Round, Category, Side, Participant)` and retains `SourceOrderID`, `TrueType`, `VerifiedQuantity`, and `TruthfulUnitReport`. `ActivationUniform` and `ExplorationUniform` are saved random draws shared across methods for matched comparisons.

The input files contain current economic types, quantities, and common random draws. Submitted bids/asks, selected price factors, utilities, and willingness are subsequently produced by the decision process. The 400 rounds are simulated interactions using source records, not 400 observed industrial trading rounds. The separate ten-sequence parameter-analysis inputs are documented in [05_parameter_sensitivity](../05_parameter_sensitivity/README.md).
