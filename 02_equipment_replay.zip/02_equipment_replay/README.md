# Equipment state replay inputs

These inputs connect the observed [PIADE equipment intervals](../01_sources/PIADE/README.md) to the replay experiment in Section 7.2. Interval states are reconciled on a half-hour grid; gaps and overlapping records are identified explicitly. Evaluation retains all 37 eight-hour windows in which every slot of all five assets has at least 95% unambiguous physical-state coverage. The windows span 19 source weeks.

## Input tables

| CSV                                                   | Rows  | Meaning                                                                                             |
| ----------------------------------------------------- | -----:| --------------------------------------------------------------------------------------------------- |
| [S1_windows.csv](inputs/S1_windows.csv)               | 37    | Window chronology, source-week identifiers, and aggregate idle/release hours.                       |
| [S1_slots.csv](inputs/S1_slots.csv)                   | 2,960 | One asset in one half-hour slot: observed states, history estimates, and scenario release capacity. |
| [S1_requests.csv](inputs/S1_requests.csv)             | 296   | Eight virtual external requests per window, including quantity, value, and deadline.                |
| [S1_provider_costs.csv](inputs/S1_provider_costs.csv) | 185   | Assumed provision cost for each asset and window.                                                   |
| [S1_calibration.csv](inputs/S1_calibration.csv)       | 5     | Asset idle fractions from 2020 used for calibration.                                                |
| [S1_dictionary.csv](inputs/S1_dictionary.csv)         | 30    | Field definitions, units, and observed/derived/scenario classifications.                            |

Tables join through `case_id`; asset-slot records additionally use `asset_id` and `slot_1based`. Reference release capacity is `0.5 hours × idle_fraction × assumed_release_fraction`, with an assumed release fraction of 0.5. External requests, valuations, and costs are controlled inputs, generated with seed `20261020`; they are not recorded factory orders.

## Original-record traceability

[S1_source_intersections.csv](lineage/S1_source_intersections.csv) links each window–asset–slot to the original data row and CSV line in PIADE. Its 17,785 intersection records allow inspection of the contributing source intervals. Overlapping intersection durations must not simply be added; overlaps are treated as conflicting coverage.

[S1_all_30min_states.csv](lineage/S1_all_30min_states.csv) preserves the full aligned state grid. [S1_extended_windows.csv](lineage/S1_extended_windows.csv) lists a separate, less restrictive extension set, which is not pooled with the 37 core windows. The two original preparation JSON files preserve historical provenance; they refer to the earlier preparation layout, rather than the current repository inventory.
