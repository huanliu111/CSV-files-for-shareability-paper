# Double auction inputs

These tables supply the fixed valuations, costs, and quantities used to evaluate the auction mechanism in Section 7.3. They are constructed from the [TORQ source and mapping](../01_sources/TORQ/README.md).

- [inputs/auction/](inputs/auction/) contains 120 markets: four total participant counts (`K=8,24,48,96`) and 30 matched replications. Each category has equal numbers of MDs and MPs; `K=24` means 12 MDs and 12 MPs per category.
- [inputs/scaling/](inputs/scaling/) contains 30 populations with 96 MDs and 96 MPs per category. Smaller MD/MP configurations use prefixes of the same population for matched scale comparisons.
- [auction_market_registry.csv](auction_market_registry.csv) identifies all 150 supplied inputs, their seeds, participant counts, and source symbols. Its paths are relative to this directory. `market_registry_full.csv` is the historical preparation registry and also includes earlier learning entries; it is not the current input inventory.

One input row represents a virtual participant in a category and round. The key is `(Seed, Round, Category, Side, Participant)`, with `Side=1` for MD and `Side=2` for MP. `TrueType` is the mapped unit valuation/cost; `VerifiedQuantity` is the fixed quantity. `TruthfulUnitReport` equals `TrueType`. The saved uniform draws support matched participation and exploration experiments.

`SourceOrderID` links every row to the retained source order. Sampling preserves the original order side, with replacement; category labels and unit conversions are scenario assumptions. These tables are auction inputs, rather than recorded manufacturing transactions.
