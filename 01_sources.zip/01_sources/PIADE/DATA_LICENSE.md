# Data attribution

Original dataset: **Packaging Industry Anomaly DEtection (PIADE) Dataset**, version 1.0.0 (2022).

Creators: Diego Tosato, Enrico Convento, Chiara Masiero, Gian Antonio Susto and Alessandro Beghi.

Persistent source: https://doi.org/10.5281/zenodo.7071747

Public file mirror and license metadata: https://researchdata.cab.unipd.it/1459/

The University of Padova mirror identifies the source CSV as **Creative Commons Attribution 4.0**. License text: https://creativecommons.org/licenses/by/4.0/

The supplied `raw_data.csv.gz` is a lossless compression of the unmodified original `raw_data.csv`. Derived state tables aggregate intervals, flag unknown/conflicting coverage, and identify eligible evaluation windows. Separate controlled scenario tables introduce hypothetical requests, release coefficients and economic inputs. These changes are identified in the S1 data dictionary and directory READMEs. No endorsement by the source creators is implied.

Retain this attribution and the change description when sharing PIADE-derived tables. This data attribution applies to PIADE records and does not assign a blanket license to unrelated datasets or software.
